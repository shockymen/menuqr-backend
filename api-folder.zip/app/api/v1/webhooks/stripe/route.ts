import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import Stripe from 'stripe'

const createServerClient = () => {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-11-20.acacia'
})

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

// POST - Stripe webhook handler
export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get('stripe-signature')

    if (!signature) {
      console.error('No Stripe signature found')
      return NextResponse.json({ error: 'No signature' }, { status: 400 })
    }

    // Verify webhook signature
    let event: Stripe.Event
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (err: any) {
      console.error('Webhook signature verification failed:', err.message)
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
    }

    const supabase = createServerClient()

    // Handle different event types
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        console.log('Checkout completed:', session.id)

        const businessId = session.metadata?.business_id
        const planId = session.metadata?.plan_id

        if (!businessId || !planId) {
          console.error('Missing metadata in checkout session')
          break
        }

        // Get the subscription from Stripe
        const stripeSubscription = await stripe.subscriptions.retrieve(
          session.subscription as string
        )

        // Get payment method details
        let paymentMethod: Stripe.PaymentMethod | null = null
        if (stripeSubscription.default_payment_method) {
          paymentMethod = await stripe.paymentMethods.retrieve(
            stripeSubscription.default_payment_method as string
          )
        }

        // Create or update subscription in database
        const { error } = await supabase
          .from('subscriptions')
          .upsert({
            business_id: businessId,
            plan_id: planId,
            stripe_subscription_id: stripeSubscription.id,
            stripe_customer_id: session.customer as string,
            stripe_payment_method_id: stripeSubscription.default_payment_method as string,
            status: stripeSubscription.status,
            current_period_start: new Date(stripeSubscription.current_period_start * 1000).toISOString(),
            current_period_end: new Date(stripeSubscription.current_period_end * 1000).toISOString(),
            trial_ends_at: stripeSubscription.trial_end 
              ? new Date(stripeSubscription.trial_end * 1000).toISOString() 
              : null,
            billing_email: session.customer_email,
            last_four: paymentMethod?.card?.last4 || null,
            card_brand: paymentMethod?.card?.brand || null,
            started_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }, {
            onConflict: 'business_id'
          })

        if (error) {
          console.error('Failed to create subscription:', error)
        }
        break
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription
        console.log('Subscription updated:', subscription.id)

        const { error } = await supabase
          .from('subscriptions')
          .update({
            status: subscription.status,
            current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
            current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
            trial_ends_at: subscription.trial_end 
              ? new Date(subscription.trial_end * 1000).toISOString() 
              : null,
            canceled_at: subscription.canceled_at 
              ? new Date(subscription.canceled_at * 1000).toISOString() 
              : null,
            updated_at: new Date().toISOString()
          })
          .eq('stripe_subscription_id', subscription.id)

        if (error) {
          console.error('Failed to update subscription:', error)
        }
        break
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription
        console.log('Subscription deleted:', subscription.id)

        const { error } = await supabase
          .from('subscriptions')
          .update({
            status: 'canceled',
            canceled_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          })
          .eq('stripe_subscription_id', subscription.id)

        if (error) {
          console.error('Failed to delete subscription:', error)
        }
        break
      }

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice
        console.log('Payment succeeded:', invoice.id)

        // Increment invoice count
        const { error } = await supabase
          .rpc('increment', { 
            row_id: invoice.subscription as string,
            column_name: 'invoice_count'
          })
          .eq('stripe_subscription_id', invoice.subscription)

        // Alternative if RPC doesn't exist:
        const { data: sub } = await supabase
          .from('subscriptions')
          .select('invoice_count')
          .eq('stripe_subscription_id', invoice.subscription)
          .single()

        if (sub) {
          await supabase
            .from('subscriptions')
            .update({
              invoice_count: (sub.invoice_count || 0) + 1,
              updated_at: new Date().toISOString()
            })
            .eq('stripe_subscription_id', invoice.subscription)
        }

        if (error) {
          console.error('Failed to update invoice count:', error)
        }
        break
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice
        console.log('Payment failed:', invoice.id)

        const { error } = await supabase
          .from('subscriptions')
          .update({
            status: 'past_due',
            updated_at: new Date().toISOString()
          })
          .eq('stripe_subscription_id', invoice.subscription)

        if (error) {
          console.error('Failed to update subscription status:', error)
        }

        // TODO: Send email notification to business owner
        break
      }

      case 'customer.subscription.trial_will_end': {
        const subscription = event.data.object as Stripe.Subscription
        console.log('Trial ending soon:', subscription.id)
        
        // TODO: Send trial ending reminder email (3 days before)
        break
      }

      default:
        console.log('Unhandled event type:', event.type)
    }

    return NextResponse.json({ received: true })

  } catch (error) {
    console.error('Webhook handler error:', error)
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 500 }
    )
  }
}
